
# D2.6 - Mini-8051 AFE Integration
## Interface Contracts

### 1. System Overview

This project models an Analog Front-End (AFE) system
integrated with a conceptual 8051-based digital controller.

Main signal path:

Sensor -> Low-Pass Filter -> MUX/S&H -> ADC -> Digital Decision

Additional path:

Filtered Analog Signal -> Comparator -> Event -> Digital Decision

System dependencies:
- Supply voltage
- Reset state
- ADC reference voltage

ADC and comparator availability is derivative-specific
for the 8051 family. External devices may be required.

The simulation is an educational system-level model,
not a transistor-level hardware implementation.

---

### 2. Sensor Interface Contract

Input:
- Simulated physical condition

Output:
- Analog voltage with noise

Range:
- Nominal sensor levels: 0.5 V and 2.8 V
- Gaussian noise standard deviation: 0.015 V

Timing:
- Simulation step: 100 ns
- Sensor transition: 1.0 us

Assumptions:
- Sensor output follows the simulated condition.
- Sensor noise is reproducible using random seed 42.

Metrics:
- Sensor output voltage
- Noise amplitude

Pass/Fail:
- PASS if the sensor output stays within the supported
  analog input range of 0 to 3.3 V.
- FAIL if the analog input exceeds that range.

---

### 3. Low-Pass Filter Interface Contract

Input:
- Noisy sensor voltage

Output:
- Filtered analog voltage

Range:
- Supported input: 0 to 3.3 V

Timing:
- Time constant: 200 ns
- Simulation step: 100 ns

Assumptions:
- First-order low-pass filter.
- Ideal mathematical filtering model.

Metrics:
- Filter output voltage
- Difference between noisy and filtered signals
- Response delay after a sensor transition

Pass/Fail:
- PASS if output remains within 0 to 3.3 V and is finite.
- Noise reduction and response delay are evaluated
  separately; no numerical noise attenuation limit
  is specified in this model.
- FAIL if output is outside the supported range
  or contains invalid numerical values.

---

### 4. MUX / Sample-and-Hold Interface Contract

Input:
- Filtered analog voltage

Output:
- Sampled analog voltage

Range:
- Supported voltage: 0 to 3.3 V

Timing:
- Normal acquisition time: 100 ns
- Fault acquisition time: 1 ns

Parameters:
- Effective resistance: 1 kohm
- Sampling capacitance: 10 pF

Assumptions:
- First-order RC settling.
- One effective resistance and one sampling capacitor.
- Sampled voltage starts from the previous sample.

Metrics:
- Acquisition settling error
- Settling error relative to ADC LSB

Pass/Fail:
- PASS if settling error <= 0.5 LSB.
- FAIL if settling error > 0.5 LSB.

Limitations:
- Switch resistance variation, charge injection,
  leakage, and ADC input nonlinearity are not modeled.

---

### 5. ADC Interface Contract

Input:
- Sampled analog voltage

Output:
- 10-bit digital code

Range:
- ADC code: 0 to 1023
- Nominal Vref: 3.3 V
- Vref during supply dip: 3.2 V

Timing:
- One ideal conversion per simulation step (100 ns).
- Conversion latency is not explicitly modeled.

Assumptions:
- Ideal 10-bit quantization.
- Code saturation at 0 and 1023.
- Quantization uses actual Vref.

Metrics:
- ADC code
- Reconstructed voltage
- Vref actual versus assumed

Pass/Fail:
- PASS if code is between 0 and 1023
  and assumed Vref matches actual Vref.
- FAIL for reference consistency when
  assumed Vref differs from actual Vref.

Note:
- Reference consistency is separate from quantization
  and settling accuracy.

---

### 6. Comparator / Event Interface Contract

Input:
- Filtered analog voltage

Output:
- Binary comparator event: 0 or 1

Threshold:
- 2.0 V

Timing:
- Evaluated once per simulation step (100 ns).
- Propagation delay is not modeled.

Assumptions:
- Ideal comparator without hysteresis.

Metrics:
- Comparator event value

Pass/Fail:
- PASS if event is 1 when filtered voltage >= 2.0 V
  and 0 otherwise.
- FAIL if event does not match this threshold rule.

---

### 7. Digital Decision Interface Contract

Input:
- ADC digital code and assumed Vref

Output:
- NORMAL or ALERT

Decision threshold:
- 2.0 V

Timing:
- Decision evaluated once per 100 ns simulation step.

Assumptions:
- Voltage is reconstructed from ADC code.
- No firmware processing delay is modeled.

Metrics:
- Reconstructed voltage
- Digital decision
- Expected decision
- Decision correctness

Pass/Fail:
- PASS if digital decision matches the decision
  based on filtered analog voltage.
- FAIL if the decisions differ.

---

### 8. Supply Interface Contract

Input:
- Simulated supply condition

Output:
- Supply voltage and associated actual Vref

Range:
- Nominal supply: 5.0 V
- Supply dip: 4.6 V

Timing:
- Supply dip interval: 1.5 us <= t < 1.9 us

Assumptions:
- Vref is 3.3 V during nominal supply.
- Vref is 3.2 V during supply dip.
- No other supply-dependent analog errors are modeled.

Metrics:
- Supply voltage
- Actual Vref
- Difference between actual and assumed Vref

Pass/Fail:
- PASS for the modeled reference interface if
  the actual Vref is correctly accounted for.
- FAIL for reference consistency if the
  assumed Vref differs from actual Vref.

---

### 9. Reset Interface Contract

Input:
- Reset condition

Output:
- Reset state: 0 or 1

Assumptions:
- Reset is inactive throughout this simulation.
- The modeled supply dip does not trigger reset.
- No brown-out reset threshold or recovery timing
  is implemented.

Metrics:
- Reset state

Pass/Fail:
- PASS if reset stays inactive under the
  stated model assumptions.
- Hardware reset behavior is not validated.

---

### 10. Integration Scenarios

Scenario A: Normal
- Acquisition time: 100 ns
- Actual Vref is used for reconstruction.
- Expected: accurate sampling and correct decisions.

Scenario B: Short Acquisition
- Acquisition time: 1 ns
- Expected: larger settling error and possible
  delayed or incorrect digital decisions.

Scenario C: Wrong Vref Assumption
- Acquisition time: 100 ns
- Firmware assumes Vref = 3.3 V.
- During supply dip, actual Vref = 3.2 V.
- Expected: reference consistency failure and
  voltage reconstruction error.

---

### 11. Acceptance Gate

The following trace must be documented:

Sensor Voltage
-> Filtered Analog Node
-> Sampled Voltage
-> ADC Digital Code
-> Reconstructed Voltage
-> Digital Decision

Evidence:
- system/block_diagram.png
- integration_results.csv
- system/integration_plot.png
- contracts.md

The integration results must include:
- Normal condition
- Short acquisition fault
- Wrong Vref assumption fault
- Supply dip
- Comparator event
- Digital decision

Reproducibility:
- Run the Python integration script.
- Regenerate the CSV and plot.
- Verify pass/fail results using the documented contracts.

This model does not validate a physical 8051 device,
a specific ADC peripheral, or a foundry-level circuit.
