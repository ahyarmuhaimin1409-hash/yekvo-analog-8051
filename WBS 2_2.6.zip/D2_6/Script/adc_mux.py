
import numpy as np
import matplotlib.pyplot as plt

N = 10
vin = np.linspace(0, 3.3, 1001)

# ADC quantization
for vref in [3.2, 3.3]:
    code = np.clip(
        np.floor(vin / vref * (2**N)),
        0,
        2**N - 1
    ).astype(int)

    plt.step(vin, code, where="post", label=f"Vref={vref}V")

plt.xlabel("Vin [V]")
plt.ylabel("ADC code")
plt.legend()
plt.tight_layout()
plt.savefig("adc_codes.png", dpi=150)

print("Ideal LSB at 3.3 V:", 3.3 / (2**N), "V")

# MUX settling
for r in [1e3, 1e4, 1e5]:
    cs = 10e-12
    taq = 100e-9

    err = (2.8 - 0.5) * np.exp(-taq / (r * cs))

    print(f"R={r:,.0f} ohm: acquisition residual={err:.6g} V")
