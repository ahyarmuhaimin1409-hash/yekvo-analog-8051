
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from pathlib import Path

# Output folder
output = Path("system")
output.mkdir(parents=True, exist_ok=True)

fig, ax = plt.subplots(figsize=(14, 8))
ax.set_xlim(0, 15)
ax.set_ylim(0, 9)
ax.axis("off")

def block(x, y, w, h, title, detail="", color="#DCEBFA"):
    rect = FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.12",
        linewidth=1.5,
        edgecolor="#24476A",
        facecolor=color
    )
    ax.add_patch(rect)
    ax.text(x + w/2, y + h*0.65, title,
            ha="center", va="center",
            fontsize=11, fontweight="bold")
    ax.text(x + w/2, y + h*0.28, detail,
            ha="center", va="center", fontsize=9)

def arrow(x1, y1, x2, y2, color="#34495E", style="-|>"):
    ax.add_patch(FancyArrowPatch(
        (x1, y1), (x2, y2),
        arrowstyle=style, mutation_scale=15,
        linewidth=1.8, color=color
    ))

# Main analog-to-digital path
block(0.3, 5.8, 2.1, 1, "SENSOR", "0.5-2.8 V + noise")
block(3.0, 5.8, 2.1, 1, "FILTER", "Low-pass")
block(5.7, 5.8, 2.1, 1, "MUX / S&H", "Sampling + settling")
block(8.4, 5.8, 2.1, 1, "ADC", "10-bit, Vref")
block(11.1, 5.8, 3.1, 1, "DIGITAL DECISION", "8051 processing")

arrow(2.4, 6.3, 3.0, 6.3)
arrow(5.1, 6.3, 5.7, 6.3)
arrow(7.8, 6.3, 8.4, 6.3)
arrow(10.5, 6.3, 11.1, 6.3)

# Comparator branch
block(5.7, 3.3, 2.1, 1, "COMPARATOR", "Threshold detection",
      "#FDEACF")
block(8.4, 3.3, 2.1, 1, "EVENT", "Digital interrupt",
      "#FDEACF")

arrow(4.05, 5.8, 4.05, 3.8)
arrow(4.05, 3.8, 5.7, 3.8)
arrow(7.8, 3.8, 8.4, 3.8)
arrow(10.5, 3.8, 12.65, 3.8)
arrow(12.65, 3.8, 12.65, 5.8)

# Dependencies
block(1.7, 1.1, 3, 1, "SUPPLY", "Nominal / voltage dip",
      "#E2F1DF")
block(5.7, 1.1, 3, 1, "RESET", "Initialization / valid state",
      "#E2F1DF")

arrow(3.2, 2.1, 3.2, 3.1, color="#27884B")
arrow(3.2, 3.1, 8.9, 3.1, color="#27884B")
arrow(8.9, 3.1, 8.9, 5.8, color="#27884B")
arrow(7.2, 2.1, 7.2, 2.7, color="#27884B")
arrow(7.2, 2.7, 13.5, 2.7, color="#27884B")
arrow(13.5, 2.7, 13.5, 5.8, color="#27884B")

ax.text(7.5, 8.2, "MINI-8051 AFE INTEGRATION",
        fontsize=17, ha="center", fontweight="bold")

ax.text(
    7.5, 7.5,
    "ADC and comparator are derivative-specific or external components",
    ha="center", fontsize=10, color="#8A3C22"
)

plt.tight_layout()
plt.savefig(output / "block_diagram.png", dpi=200,
            bbox_inches="tight")
plt.close()

print("Block diagram saved to system/block_diagram.png")
