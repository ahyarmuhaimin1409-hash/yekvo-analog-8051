
import numpy as np
import csv
from pathlib import Path
import matplotlib.pyplot as plt

# ==========================================
# D2.6 - MINI 8051 AFE INTEGRATION
# Educational system-level model
# ==========================================

OUT = Path("integration_results.csv")
PLOT = Path("system/integration_plot.png")
PLOT.parent.mkdir(parents=True, exist_ok=True)

N = 10
CS = 10e-12
R = 1e3
VREF_NOMINAL = 3.3
THRESHOLD = 2.0

# Time points: 0 to 3 us, every 100 ns
dt = 100e-9
time = np.arange(31) * dt

# Repeatable noise
rng = np.random.default_rng(42)
noise = rng.normal(0, 0.015, len(time))

# Sensor changes from 0.5 V to 2.8 V at 1 us
sensor_ideal = np.where(time < 1e-6, 0.5, 2.8)
sensor = sensor_ideal + noise

# Low-pass filter with tau = 200 ns
tau_filter = 200e-9
alpha = 1 - np.exp(-dt / tau_filter)

filtered = np.zeros_like(sensor)
filtered[0] = sensor[0]

for i in range(1, len(time)):
    filtered[i] = (
        filtered[i - 1]
        + alpha * (sensor[i] - filtered[i - 1])
    )

# Supply dip from 1.5 us to 1.9 us
supply = np.where(
    (time >= 1.5e-6) & (time < 1.9e-6),
    4.6,
    5.0
)

# Assumption: Vref changes during supply dip
vref_actual = np.where(supply < 5.0, 3.2, 3.3)

scenarios = {
    "normal": {
        "taq": 100e-9,
        "wrong_vref": False
    },
    "short_acquisition": {
        "taq": 1e-9,
        "wrong_vref": False
    },
    "wrong_vref_assumption": {
        "taq": 100e-9,
        "wrong_vref": True
    }
}

rows = []
plot_data = {}

for scenario, settings in scenarios.items():

    previous_sample = filtered[0]
    reconstructed_values = []
    adc_codes = []

    for i, t in enumerate(time):

        taq = settings["taq"]
        actual_ref = vref_actual[i]

        # MUX / Sample and Hold settling
        sampled = filtered[i] + (
            previous_sample - filtered[i]
        ) * np.exp(-taq / (R * CS))

        previous_sample = sampled

        # ADC conversion uses actual Vref
        code = int(np.clip(
            np.floor(sampled / actual_ref * 2**N),
            0,
            2**N - 1
        ))

        # Firmware voltage reconstruction
        assumed_ref = (
            VREF_NOMINAL
            if settings["wrong_vref"]
            else actual_ref
        )

        reconstructed = code * assumed_ref / 2**N

        # Digital decision
        decision = (
            "ALERT"
            if reconstructed >= THRESHOLD
            else "NORMAL"
        )

        # Comparator uses filtered analog voltage
        comparator_event = int(filtered[i] >= THRESHOLD)

        # Expected decision at filter output
        expected = (
            "ALERT"
            if filtered[i] >= THRESHOLD
            else "NORMAL"
        )

        # Interface checks
        lsb = actual_ref / 2**N
        settling_error = abs(filtered[i] - sampled)

        settling_pass = settling_error <= 0.5 * lsb
        reference_pass = abs(assumed_ref - actual_ref) < 1e-9
        decision_pass = decision == expected

        rows.append({
            "scenario": scenario,
            "time_us": round(t * 1e6, 3),
            "sensor_ideal_v": round(sensor_ideal[i], 6),
            "sensor_noisy_v": round(sensor[i], 6),
            "filter_v": round(filtered[i], 6),
            "sampled_v": round(sampled, 6),
            "settling_error_v": round(settling_error, 6),
            "supply_v": round(supply[i], 3),
            "vref_actual_v": round(actual_ref, 3),
            "vref_assumed_v": round(assumed_ref, 3),
            "adc_code": code,
            "reconstructed_v": round(reconstructed, 6),
            "comparator_event": comparator_event,
            "reset_active": 0,
            "expected_decision": expected,
            "decision": decision,
            "settling_pass": settling_pass,
            "reference_pass": reference_pass,
            "decision_pass": decision_pass
        })

        reconstructed_values.append(reconstructed)
        adc_codes.append(code)

    plot_data[scenario] = {
        "reconstructed": reconstructed_values,
        "codes": adc_codes
    }

# Save integration trace
with OUT.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

# Plot selected analog and reconstructed signals
plt.figure(figsize=(11, 6))
plt.plot(time * 1e6, sensor, label="Sensor + noise", alpha=0.5)
plt.plot(time * 1e6, filtered, label="Filtered analog node")
plt.plot(
    time * 1e6,
    plot_data["normal"]["reconstructed"],
    label="Normal ADC reconstruction"
)
plt.plot(
    time * 1e6,
    plot_data["short_acquisition"]["reconstructed"],
    label="Short acquisition"
)
plt.axhline(
    THRESHOLD,
    color="gray",
    linestyle="--",
    label="Decision threshold"
)
plt.axvspan(1.5, 1.9, alpha=0.12, label="Supply dip")

plt.xlabel("Time (us)")
plt.ylabel("Voltage (V)")
plt.title("Mini-8051 AFE End-to-End Simulation")
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(PLOT, dpi=180)
plt.close()

print("Simulation completed!")
print(f"CSV saved: {OUT}")
print(f"Plot saved: {PLOT}")
print(f"Total data rows: {len(rows)}")

for scenario in scenarios:
    subset = [r for r in rows if r["scenario"] == scenario]
    failures = sum(not r["decision_pass"] for r in subset)
    settling_failures = sum(not r["settling_pass"] for r in subset)
    reference_failures = sum(not r["reference_pass"] for r in subset)
    print(
        f"{scenario}: decision failures={failures}, "
        f"settling failures={settling_failures}, "
        f"reference failures={reference_failures}"
    )
