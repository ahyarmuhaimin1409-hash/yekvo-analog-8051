
# D1.6 - CMOS Inverter Simulation

## Objective
Simulate a CMOS inverter using ngspice and analyze the effect
of load capacitance (Cload) on transient response.

## Tools
- Windows
- ngspice 47
- Python 3.14.3
- NumPy 2.4.2
- Matplotlib 3.10.8

## Circuit
- CMOS inverter (PMOS and NMOS)
- VDD: 5 V
- Input period: 200 ns
- Transient simulation: 600 ns
- Cload variations: 20 pF and 50 pF
- MOSFET model: Level-1 (teaching model)

## How to Run

Open a terminal in the project root directory.

### 1. Run ngspice simulation

```powershell
ngspice -b inverter_20p.cir
ngspice -b inverter_50p.cir
```

If ngspice is not configured in PATH, use the full
path to the ngspice executable.

### 2. Generate comparison plot

```powershell
py Script/compare.py
```

The plotting script reads:
- results/data/inverter_20p.csv
- results/data/inverter_50p.csv

The generated plot is saved to:
- results/plots/comparison.png

## Results
The 50 pF load produces slower output voltage transitions
than the 20 pF load.

Increasing Cload increases the charge required to change
the output voltage, resulting in slower switching.

## Reproducibility
The project includes:
- SPICE netlists
- Simulation CSV files
- Python plotting scripts
- Simulation logs
- Software version information

The MOS Level-1 model is for educational purposes only.
Timing results do not represent a foundry PDK.
