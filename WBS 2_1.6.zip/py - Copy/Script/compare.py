import numpy as np
import matplotlib.pyplot as plt

# Membaca hasil simulasi
data20 = np.loadtxt("results/data/inverter_20p.csv")
data50 = np.loadtxt("results/data/inverter_50p.csv")

# ngspice wrdata menghasilkan 4 kolom:
# waktu VIN, VIN, waktu VOUT, VOUT
time20 = data20[:, 0] * 1e9
time50 = data50[:, 0] * 1e9

vin20 = data20[:, 1]
vout20 = data20[:, 3]
vout50 = data50[:, 3]

# Membuat grafik perbandingan
plt.figure(figsize=(11, 6))

plt.plot(time20, vin20, "--", color="gray",
         label="Input Voltage (VIN)", alpha=0.7)

plt.plot(time20, vout20, color="blue",
         label="VOUT - Cload 20 pF")

plt.plot(time50, vout50, color="red",
         label="VOUT - Cload 50 pF")

plt.xlabel("Time (ns)")
plt.ylabel("Voltage (V)")
plt.title("CMOS Inverter: Cload 20 pF vs 50 pF")
plt.legend()
plt.grid(True)

plt.xlim(0, 600)
plt.tight_layout()

# Simpan hasil grafik
plt.savefig("results/plots/comparison.png", dpi=300)

plt.show()
