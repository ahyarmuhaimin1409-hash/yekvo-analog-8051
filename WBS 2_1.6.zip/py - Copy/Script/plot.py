import numpy as np
import matplotlib.pyplot as plt

# Membaca data hasil simulasi YEKVO
data = np.loadtxt("results/data/inverter_transient.csv")

# ngspice mengekspor pasangan waktu-nilai untuk tiap sinyal
time = data[:, 0]
vin = data[:, 1]
vout = data[:, 3]

# Membuat grafik
plt.figure(figsize=(10, 5))
plt.plot(time * 1e9, vin, label="Input Voltage (VIN)")
plt.plot(time * 1e9, vout, label="Output Voltage (VOUT)")

plt.xlabel("Time (ns)")
plt.ylabel("Voltage (V)")
plt.title("CMOS Inverter Transient - Cload 20 pF")
plt.legend()
plt.grid(True)

plt.savefig("results/plots/inverter_20p.png", dpi=300)
plt.show()